export const selectCategoriesMap = (state) => state.categories.categories
    .reduce((acc,category)=>{ // querySnapshot.docs = an array of all document snapshots, .reduce(...) transforms the array of documents into an object map
        const {title, items} = category; 
        acc[title.toLowerCase()] = items;
        return acc;
    }, {});
;
// this file is meant to transform the data we got into the final shap the reducer should be storing