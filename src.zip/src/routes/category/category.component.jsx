import './category.styles.scss';
import { useParams } from 'react-router-dom';
import { useState,useEffect, Fragment } from 'react';
import ProductCard from '../../components/product-card/product-card.component';
import { selectCategoriesMap } from '../../store/categories/category.selector';
import { useSelector } from 'react-redux';

const Category = () =>{
    const categoriesMap = useSelector(selectCategoriesMap);
    const {category} = useParams();
    const [products, setProducts] = useState(categoriesMap[category]);

    useEffect (()=>{
        setProducts(categoriesMap[category]);
    }, [category,categoriesMap])

    return (
        <Fragment>
            <h2 className='category-title'>{category.toLocaleUpperCase()}</h2>
            <div className='category-container'>
                
                { products && // this is a safe guard to make sure this function don't map until we have the products from the db
                    products.map((product) => <ProductCard key={product.id} product={product}></ProductCard>)
                }
            </div>
        </Fragment>
    );

}

export default Category;